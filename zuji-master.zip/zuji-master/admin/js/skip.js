$(document).ready(function () {

    $(".layui-header img").click(function () {
        //logo图-点击
        window.location.href = "backstage.html";
    });


});